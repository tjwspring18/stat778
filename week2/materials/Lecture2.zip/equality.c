#include <stdio.h>

int main()
{
    int x, y;
    
    x = 3; y = 3;
    
    if (x != y)
    {
        printf("x != y\n");
    }
    else
        printf("x is equal to y\n");
    
    return 0;
}

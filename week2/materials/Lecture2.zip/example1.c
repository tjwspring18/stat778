#include <stdio.h>

int main()
{
	const char str[] = "some test";

	if (str)
		printf("str is not null\n");

	return 0;
}


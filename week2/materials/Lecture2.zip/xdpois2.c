#include <stdio.h>
#include <math.h>
#include "dpois_routines.h"

int main()
{
    printf("%f\n", dpois(4,0.8));
}
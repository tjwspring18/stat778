int factorial2(int n);
double dpois(int x, double mu);
int factorial1(int n);

#include <stdio.h>
#include <math.h>
#include "dpois_routines.h"
#include "dpois_routines.c"

int main()
{
    printf("%f\n", dpois(4,0.8));
}